package rentPayment;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class Payments implements ActionListener {
	JFrame f=new JFrame("Rent Payment Informations");
	JLabel Pid=new JLabel("Payment ID:");
	JLabel Tid=new JLabel("payment ID:");
	JLabel Aid=new JLabel("Agreement ID:");
	JLabel Pdate=new JLabel("Payment Date:");
	JLabel Amount=new JLabel("Amount:");
	JLabel Pmethod=new JLabel("Payment Method:");
	JLabel Status=new JLabel("Status:");
	JTextField Pidf=new JTextField();
	JTextField Tidf=new JTextField();
	JTextField Aidf=new JTextField();
	JTextField Pdatef=new JTextField();
	JTextField Amountf=new JTextField();
	JTextField Pmethodf=new JTextField();
	JTextField Statusf=new JTextField();
	
	JButton c=new JButton("new");
	JButton r=new JButton("Reset");
	JButton d=new JButton("Delete");
	JButton u=new JButton("Update");
	JButton ret=new JButton("Retrieve");
	public Payments() {
		f();
	}
	private void f() {
		//set frame methos
		f.setBounds(500, 150, 400, 400);
		f.getContentPane().setLayout(null);
		f.setVisible(true);
		c.setBounds(20, 270, 80, 20);f.add(c);
		r.setBounds(100, 270, 80, 20);f.add(r);
		d.setBounds(180, 270, 80, 20);f.add(d);
		ret.setBounds(260, 270, 80, 20);f.add(ret);
		u.setBounds(20, 295, 80, 20);f.add(u);
		f.add(Pid);
		f.add(Tid);
		f.add(Aid);
		f.add(Pdate);
		f.add(Amount);
		f.add(Pmethod);
		f.add(Status);
		f.add(Pidf);
		f.add(Tidf);
		f.add(Aidf);
		f.add(Pdatef);
		f.add(Amountf);
		
		c.addActionListener(this);
		r.addActionListener(this);
		d.addActionListener(this);
		u.addActionListener(this);
		ret.addActionListener(this);
		f.add(Pmethodf);
		f.add(Statusf);
		Pid.setBounds(20, 20, 150, 20);
		Tid.setBounds(20, 45, 150, 20);
		Aid.setBounds(20, 70, 150, 20);
		Pdate.setBounds(20, 95, 150, 20);
		Amount.setBounds(20, 120, 150, 20);
		Pmethod.setBounds(20, 145, 150, 20);
		Status.setBounds(20, 170, 150, 20);
		Pidf.setBounds(160, 20, 150, 20);
	    Tidf.setBounds(160, 45, 150, 20);
		Aidf.setBounds(160, 70, 150, 20);
		Pdatef.setBounds(160, 95, 150, 20);
		Amountf.setBounds(160, 120, 150, 20);
		Pmethodf.setBounds(160, 145, 150, 20);
		Statusf.setBounds(160, 170, 150, 20);
	}
	public static void main(String [] args) {
	Payments add=new Payments();
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==c) {
			c();
		}
	if(e.getSource()==r) {
		r();
	}
	if(e.getSource()==d) {
		d();
	}

	if(e.getSource()==u) {
		u();
	}
	
	if(e.getSource()==ret) {
		ret();
	}
		
	}
	private void c() {
		String dbURL = "jdbc:mysql://localhost:3306/rent";
		String username = "root";
		String password = "";
		
		String id=Pidf.getText();
		String fname=Tidf.getText();
		String lname=Aidf.getText();
		String phone=Amountf.getText();
		String email=Pdatef.getText();
		String address=Pmethodf.getText();
		String leaseS=Statusf.getText();
		try {
		 
		    Connection conn = DriverManager.getConnection(dbURL, username, password);
		  
		    if (conn != null) {
		    	   JOptionPane.showMessageDialog(null, "Connected","",JOptionPane.INFORMATION_MESSAGE);
		        String sql = "INSERT INTO payment (payid, Tid, Aid, Pdate,amount,pmethod,status) VALUES (?, ?, ?, ?,?,?,?)";
			    
			    PreparedStatement statement = conn.prepareStatement(sql);
			    statement.setString(1, id);
			    statement.setString(2, fname);
			    statement.setString(3, lname);
			    statement.setString(4, phone);
			    statement.setString(5, email);
			    statement.setString(6, address);
			    statement.setString(7, leaseS);
			  
			    int rowsInserted = statement.executeUpdate();
			    if (rowsInserted > 0) {
			        JOptionPane.showMessageDialog(null, "Done to Insert","",JOptionPane.INFORMATION_MESSAGE);
			    }
		    }
		} catch (SQLException ex) {
		    ex.printStackTrace();
		}
		
		Pidf.setText("");
		Tidf.setText("");
		Aidf.setText("");
		Pdatef.setText("");
		Amountf.setText("");
		Pmethodf.setText("");
		Statusf.setText("");
	
		
	}
	private void ret() {
		String dbURL = "jdbc:mysql://localhost:3306/rent";
		String username = "root";
		String password = "";
		String id=Pidf.getText();
		try {
		 
		    Connection conn = DriverManager.getConnection(dbURL, username, password);
		 
		    if (conn != null) {
		    	   JOptionPane.showMessageDialog(null, "Connected","",JOptionPane.INFORMATION_MESSAGE);
		        String sql = "SELECT * FROM payment where payid='"+id+"'";
		        
		        Statement statement = conn.createStatement();
		        ResultSet result = statement.executeQuery(sql);
		
		        while (result.next()){
		            String fname= result.getString(2);
		            String lname = result.getString(3);
		            String phone = result.getString(4);
		            String email = result.getString(5);
		            String address = result.getString(6);
		            String leaseS = result.getString(7);
		            
		           
					Tidf.setText(fname);
					Aidf.setText(lname);
					Pdatef.setText(phone);
					Amountf.setText(email);
					Pmethodf.setText(address);
					
					Statusf.setText(leaseS);
		        }
		    }
		} catch (SQLException ex) {
		    ex.printStackTrace();
		}
		
	}
	private void u() {
		String dbURL = "jdbc:mysql://localhost:3306/rent";
		String username = "root";
		String password = "";
		String id=Pidf.getText();
		String fname=Tidf.getText();
		String lname=Aidf.getText();
		String phone=Amountf.getText();
		String email=Pdatef.getText();
		String address=Pmethodf.getText();
		String leaseS=Statusf.getText();
		
	
		try {
		 
		    Connection conn = DriverManager.getConnection(dbURL, username, password);
		 
		    if (conn != null) {
		    	  JOptionPane.showMessageDialog(null, "Connected","",JOptionPane.INFORMATION_MESSAGE);
		        String sql = "UPDATE payment SET Tid=?, Aid=?, Pdate=?,amount=?,pmethod=?,status=? WHERE payid=?";
		        
		        PreparedStatement statement = conn.prepareStatement(sql);
		       
		        statement.setString(1, fname);
		        statement.setString(2, lname);
		        statement.setString(3, phone);
		        statement.setString(4, email);
		        statement.setString(5, address);
		        statement.setString(6, leaseS);
		        statement.setString(7, id);
		        int rowsUpdated = statement.executeUpdate();
		        if (rowsUpdated > 0) {
		        	  JOptionPane.showMessageDialog(null, "Done to Update","",JOptionPane.INFORMATION_MESSAGE);
		        }
		    }
		} catch (SQLException ex) {
		    ex.printStackTrace();
		}
		Pidf.setText("");
		Tidf.setText("");
		Aidf.setText("");
		Pdatef.setText("");
		Amountf.setText("");
		Pmethodf.setText("");
		Statusf.setText("");
	}
	private void d() {
		String dbURL = "jdbc:mysql://localhost:3306/rent";
		String username = "root";
		String password = "";
		String id=Pidf.getText();
		try {
		 
		    Connection conn = DriverManager.getConnection(dbURL, username, password);
		 
		    if (conn != null) {
		    	  JOptionPane.showMessageDialog(null, "Connected","",JOptionPane.INFORMATION_MESSAGE);
		        String sql = "DELETE FROM payment WHERE payid=?";
		        
		        PreparedStatement statement = conn.prepareStatement(sql);
		        statement.setString(1, id);
		         
		        int rowsDeleted = statement.executeUpdate();
		        if (rowsDeleted > 0) {
		        	  JOptionPane.showMessageDialog(null, "Done to Delete","",JOptionPane.INFORMATION_MESSAGE);
		        }
		    }
		} catch (SQLException ex) {
		    ex.printStackTrace();
		}
		Pidf.setText("");
		Tidf.setText("");
		Aidf.setText("");
		Pdatef.setText("");
		Amountf.setText("");
		Pmethodf.setText("");
		Statusf.setText("");
	}
	private void r() {
		Pidf.setText("");
		Tidf.setText("");
		Aidf.setText("");
		Pdatef.setText("");
		Amountf.setText("");
		Pmethodf.setText("");
		Statusf.setText("");
		
	}
}
