package owner;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class Owner implements ActionListener {
	JFrame f=new JFrame("owner Informations");
	JLabel Pid=new JLabel(" ID:");
	JLabel fname=new JLabel("First Name:");
	JLabel lname=new JLabel("Last Name:");
	JLabel phone=new JLabel("Phone:");
	JLabel email=new JLabel("Last Name:");
	JLabel address=new JLabel("Adress:");
	JTextField Pidf=new JTextField();
	JTextField fnamef=new JTextField();
	JTextField lnamef=new JTextField();
	JTextField phonef=new JTextField();
	JTextField emailf=new JTextField();
	JTextField addressf=new JTextField();
	JButton c=new JButton("new");
	JButton r=new JButton("Reset");
	JButton d=new JButton("Delete");
	JButton u=new JButton("Update");
	JButton ret=new JButton("Retrieve");
	public Owner() {
		f();
	}
	private void f() {
		//set frame methos
		f.setBounds(500, 150, 400, 500);
		f.getContentPane().setLayout(null);
		f.setVisible(true);
		f.add(Pid);
		f.add(fname);
		f.add(lname);
		f.add(phone);
		f.add(email);
		f.add(address);
		f.add(Pidf);
		f.add(fnamef);
		f.add(lnamef);
		f.add(phonef);
		f.add(emailf);
		f.add(addressf);
		Pid.setBounds(20, 20, 150, 20);
		fname.setBounds(20, 45, 150, 20);
		lname.setBounds(20, 70, 150, 20);
		phone.setBounds(20, 95, 150, 20);
		email.setBounds(20, 120, 150, 20);
		address.setBounds(20, 145, 150, 20);
		Pidf.setBounds(160, 20, 150, 20);
		fnamef.setBounds(160, 45, 150, 20);
		lnamef.setBounds(160, 70, 150, 20);
		phonef.setBounds(160, 95, 150, 20);
		emailf.setBounds(160, 120, 150, 20);
		addressf.setBounds(160, 145, 150, 20);
		u.setBounds(20, 295, 80, 20);f.add(u);
		c.setBounds(20, 270, 80, 20);f.add(c);
		r.setBounds(100, 270, 80, 20);f.add(r);
		d.setBounds(180, 270, 80, 20);f.add(d);
		ret.setBounds(260, 270, 80, 20);f.add(ret);
		
		c.addActionListener(this);
		r.addActionListener(this);
		d.addActionListener(this);
		u.addActionListener(this);
		ret.addActionListener(this);
	}
	public static void main(String [] args) {
	Owner add=new Owner();
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==c) {
			c();
		}
	if(e.getSource()==r) {
		r();
	}
	if(e.getSource()==d) {
		d();
	}

	if(e.getSource()==u) {
		u();
	}
	
	if(e.getSource()==ret) {
		ret();
	}
		
	}
	private void c() {
		String dbURL = "jdbc:mysql://localhost:3306/rent";
		String username = "root";
		String password = "";
		String id=Pidf.getText();
		String fname=fnamef.getText();
		String lname=lnamef.getText();
		String phone=phonef.getText();
		String email=emailf.getText();
		String address=addressf.getText();;
		try {
		 
		    Connection conn = DriverManager.getConnection(dbURL, username, password);
		  
		    if (conn != null) {
		    	   JOptionPane.showMessageDialog(null, "Connected","",JOptionPane.INFORMATION_MESSAGE);
		        String sql = "INSERT INTO owner (owoid, fname, lname, phone,email,address) VALUES (?, ?, ?, ?,?,?)";
			    
			    PreparedStatement statement = conn.prepareStatement(sql);
			    statement.setString(1, id);
			    statement.setString(2, fname);
			    statement.setString(3, lname);
			    statement.setString(4, phone);
			    statement.setString(5, email);
			    statement.setString(6, address);
			  
			  
			    int rowsInserted = statement.executeUpdate();
			    if (rowsInserted > 0) {
			        JOptionPane.showMessageDialog(null, "Done to Insert","",JOptionPane.INFORMATION_MESSAGE);
			    }
		    }
		} catch (SQLException ex) {
		    ex.printStackTrace();
		}
		
		Pidf.setText("");
		fnamef.setText("");
		lnamef.setText("");
		addressf.setText("");
		phonef.setText("");
		emailf.setText("");
	
	
		
	}
	private void ret() {
		String dbURL = "jdbc:mysql://localhost:3306/rent";
		String username = "root";
		String password = "";
		String id=Pidf.getText();
		try {
		 
		    Connection conn = DriverManager.getConnection(dbURL, username, password);
		 
		    if (conn != null) {
		    	   JOptionPane.showMessageDialog(null, "Connected","",JOptionPane.INFORMATION_MESSAGE);
		        String sql = "SELECT * FROM owner where owoid='"+id+"'";
		        
		        Statement statement = conn.createStatement();
		        ResultSet result = statement.executeQuery(sql);
		
		        while (result.next()){
		            String fname= result.getString(2);
		            String lname = result.getString(3);
		            String phone = result.getString(4);
		            String email = result.getString(5);
		            String address = result.getString(6);
		           
		           
					fnamef.setText(fname);
					lnamef.setText(lname);
					addressf.setText(phone);
					phonef.setText(email);
					emailf.setText(address);
					
					
		        }
		    }
		} catch (SQLException ex) {
		    ex.printStackTrace();
		}
		
	}
	private void u() {
		String dbURL = "jdbc:mysql://localhost:3306/rent";
		String username = "root";
		String password = "";
		String id=Pidf.getText();
		String fname=fnamef.getText();
		String lname=lnamef.getText();
		String phone=phonef.getText();
		String email=emailf.getText();
		String address=addressf.getText();;
	
		
	
		try {
		 
		    Connection conn = DriverManager.getConnection(dbURL, username, password);
		 
		    if (conn != null) {
		    	  JOptionPane.showMessageDialog(null, "Connected","",JOptionPane.INFORMATION_MESSAGE);
		        String sql = "UPDATE owner SET fname=?, lname=?, phone=?,email=?,address=? WHERE owoid=?";
		        
		        PreparedStatement statement = conn.prepareStatement(sql);
		     
		        statement.setString(1, fname);
		        statement.setString(2, lname);
		        statement.setString(3, phone);
		        statement.setString(4, email);
		        statement.setString(5, address);
		        statement.setString(6, id);
		      
		        int rowsUpdated = statement.executeUpdate();
		        if (rowsUpdated > 0) {
		        	  JOptionPane.showMessageDialog(null, "Done to Update","",JOptionPane.INFORMATION_MESSAGE);
		        }
		    }
		} catch (SQLException ex) {
		    ex.printStackTrace();
		}
		Pidf.setText("");
		fnamef.setText("");
		lnamef.setText("");
		addressf.setText("");
		phonef.setText("");
		emailf.setText("");
	}
	private void d() {
		String dbURL = "jdbc:mysql://localhost:3306/rent";
		String username = "root";
		String password = "";
		String id=Pidf.getText();
		try {
		 
		    Connection conn = DriverManager.getConnection(dbURL, username, password);
		 
		    if (conn != null) {
		    	  JOptionPane.showMessageDialog(null, "Connected","",JOptionPane.INFORMATION_MESSAGE);
		        String sql = "DELETE FROM owner WHERE owoid=?";
		        
		        PreparedStatement statement = conn.prepareStatement(sql);
		        statement.setString(1, id);
		         
		        int rowsDeleted = statement.executeUpdate();
		        if (rowsDeleted > 0) {
		        	  JOptionPane.showMessageDialog(null, "Done to Delete","",JOptionPane.INFORMATION_MESSAGE);
		        }
		    }
		} catch (SQLException ex) {
		    ex.printStackTrace();
		}
		Pidf.setText("");
		fnamef.setText("");
		lnamef.setText("");
		addressf.setText("");
		phonef.setText("");
		emailf.setText("");
	}
	private void r() {
		Pidf.setText("");
		fnamef.setText("");
		lnamef.setText("");
		addressf.setText("");
		phonef.setText("");
		emailf.setText("");
		
	}
}
