package owner;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.*;

import leaseAgreement.LeaseAgreement;
import maintenanceRequest.MaintenanceRequest;
import property.AddProperty;
import rentPayment.Payments;
import tenant.Tenant;
public class Come implements ActionListener {
	JFrame f=new JFrame("Add  Informations");

	JButton c=new JButton("Owner");
	JButton r=new JButton("Add Property");
	JButton d=new JButton("Payments");
	JButton u=new JButton("MaintenanceRequest");
	JButton ret=new JButton("Tenants");
	JButton ll=new JButton("Lease Agreement");
	public Come() {
		f();
	}
	private void f() {
		//set frame methos
		f.setBounds(-5, 0, 2000, 800);
		f.getContentPane().setLayout(null);
		f.setVisible(true);

		u.setBounds(50, 295, 250, 50);f.add(u);
		c.setBounds(300, 270, 250, 50);f.add(c);
		r.setBounds(500, 270, 250, 50);f.add(r);
		d.setBounds(700, 270, 250, 50);f.add(d);
		ret.setBounds(960, 270, 250, 50);f.add(ret);
		ll.setBounds(60, 360, 250, 50);f.add(ll);
		c.addActionListener(this);
		r.addActionListener(this);
		d.addActionListener(this);
		u.addActionListener(this);
		ret.addActionListener(this);
		ll.addActionListener(this);
	}
	public static  void main(String [] args) {
		Come add=new Come();
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==c) {
		Owner o=	new Owner();
		
		}
	if(e.getSource()==r) {
	AddProperty ad=new	AddProperty();
	}
	if(e.getSource()==d) {
	Payments p=new	Payments();
	}

	if(e.getSource()==u) {
		MaintenanceRequest m=new	MaintenanceRequest();
	}
	
	if(e.getSource()==ret) {
	Tenant t=new	Tenant();
	}
	
	if(e.getSource()==ll) {
		LeaseAgreement t=new	LeaseAgreement();
		}
		
	}
	
	}
	

