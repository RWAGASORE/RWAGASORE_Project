-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 10, 2023 at 05:54 PM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 7.4.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rent`
--

-- --------------------------------------------------------

--
-- Table structure for table `agreement`
--

CREATE TABLE `agreement` (
  `agreeid` varchar(100) NOT NULL,
  `pid` varchar(100) NOT NULL,
  `tid` varchar(77) NOT NULL,
  `Sdate` varchar(100) NOT NULL,
  `Edate` varchar(66) NOT NULL,
  `rentam` varchar(100) NOT NULL,
  `security` varchar(100) NOT NULL,
  `terms` varchar(77) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `agreement`
--

INSERT INTO `agreement` (`agreeid`, `pid`, `tid`, `Sdate`, `Edate`, `rentam`, `security`, `terms`) VALUES
('', '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `maintenance`
--

CREATE TABLE `maintenance` (
  `requestid` varchar(100) NOT NULL,
  `pid` varchar(100) NOT NULL,
  `tid` varchar(100) NOT NULL,
  `date` varchar(100) NOT NULL,
  `descr` varchar(77) NOT NULL,
  `status` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `maintenance`
--

INSERT INTO `maintenance` (`requestid`, `pid`, `tid`, `date`, `descr`, `status`) VALUES
('', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `owner`
--

CREATE TABLE `owner` (
  `owoid` varchar(100) NOT NULL,
  `fname` varchar(100) NOT NULL,
  `lname` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `owner`
--

INSERT INTO `owner` (`owoid`, `fname`, `lname`, `phone`, `email`, `address`) VALUES
('hhhh', 'nnnn', 'nnn', 'nn', 'nn', 'nnn'),
('88', 'nn', 'nn0000', 'kkk8888', 'nn', 'mm');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `payid` varchar(100) NOT NULL,
  `tid` varchar(100) NOT NULL,
  `aid` varchar(100) NOT NULL,
  `pdate` varchar(100) NOT NULL,
  `amount` varchar(100) NOT NULL,
  `pmethod` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`payid`, `tid`, `aid`, `pdate`, `amount`, `pmethod`, `status`) VALUES
('', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `property`
--

CREATE TABLE `property` (
  `proid` varchar(100) NOT NULL,
  `pname` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `price` varchar(100) NOT NULL,
  `category` varchar(77) NOT NULL,
  `status` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `property`
--

INSERT INTO `property` (`proid`, `pname`, `address`, `price`, `category`, `status`) VALUES
('', '', '', '', '', ''),
('hjjh', 'mm', 'mm', 'mm', 'mm', 'mm');

-- --------------------------------------------------------

--
-- Table structure for table `tenant`
--

CREATE TABLE `tenant` (
  `tentid` varchar(100) NOT NULL,
  `TFName` varchar(77) NOT NULL,
  `TLName` varchar(100) NOT NULL,
  `Phone` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `leaseS` varchar(100) NOT NULL,
  `leaseE` varchar(66) NOT NULL,
  `rentam` varchar(77) NOT NULL,
  `paystat` varchar(77) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tenant`
--

INSERT INTO `tenant` (`tentid`, `TFName`, `TLName`, `Phone`, `email`, `address`, `leaseS`, `leaseE`, `rentam`, `paystat`) VALUES
('', '', '', '', '', '', '', '', '', ''),
('55', 'hh', 'nn', 'nn', 'nn', 'nn', 'nn', 'nn', 'nn', 'nn0000');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `agreement`
--
ALTER TABLE `agreement`
  ADD PRIMARY KEY (`agreeid`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`payid`);

--
-- Indexes for table `property`
--
ALTER TABLE `property`
  ADD PRIMARY KEY (`proid`);

--
-- Indexes for table `tenant`
--
ALTER TABLE `tenant`
  ADD PRIMARY KEY (`tentid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
